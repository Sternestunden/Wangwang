package com.wangwang.ecnutrade.pojo;

public class trade {

}
