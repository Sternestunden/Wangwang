package com.wangwang.ecnutrade.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Result<T>{
    private Integer code;
    private String message;
    private T data;
    public static <E> Result<E> sucess(E data){
        return new Result<>(0,"sucess",data);
    }
    public static Result sucess(){
        return new Result(0,"sucess",null);
    }
    public static Result error(String message){
        return new Result(1,message,null);
    }
}
