package com.wangwang.ecnutrade.pojo;

import lombok.Data;

@Data
public class User {
    private int phoneNumber;
    private int ID;
    private String username;
    private String password;
    private String email;
    private String weixinId;
    private String studentPicture;
    private int reputationValue;
    private int state;
}
