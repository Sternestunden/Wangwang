package com.wangwang.ecnutrade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcnuTradeApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcnuTradeApplication.class, args);
    }

}
